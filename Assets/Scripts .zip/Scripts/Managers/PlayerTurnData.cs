using UnityEngine;

public class PlayerTurnData
{
    public PlayerMover player;
    public int roll;
}

